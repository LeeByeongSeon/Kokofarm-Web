<?
	include_once("../common/common_func.php");
	
	$userID=chkCHAR($_REQUEST["userID"]);
	$userPW=chkCHAR($_REQUEST["userPW"]);

	//01-유효한 ID/PW인지를 확인
	$strSql="SELECT fFarmid,fName FROM farm WHERE fID='$userID' AND fPW='$userPW'";
	$getData=multiFindData($strSql,localDB_Conn);

	$farmID=$getData[0]["fFarmid"];	//농장ID
	$farmNAME=$getData[0]["fName"];	//농장명

	if(!empty($farmID)){
		$strSql="SELECT fdFarmid, fdDongid, fdName FROM farm_detail WHERE fdFarmid='$farmID'"; 
		$getData=multiFindData($strSql,localDB_Conn);
		foreach($getData as $Val){
			$strSql="SELECT cmCode,IFNULL(DATEDIFF(current_date(),cmIndate)+1,0) as inTERM
					 FROM comein_master
					 WHERE cmFarmid='" . $Val["fdFarmid"] . "' AND cmDongid='" . $Val["fdDongid"] . "' AND IFNULL(LENGTH(cmIndate),0)>=4 AND IFNULL(LENGTH(cmOutdate),0)<=4";
			$chkData=multiFindData($strSql,localDB_Conn);
			$cmCode=$chkData[0]["cmCode"];
			$inTERM=$chkData[0]["inTERM"];
			
			if(!empty($cmCode) && !empty($inTERM)) {
				$menuHTML .="<li><a data-farmID='" . $Val["fdFarmid"] . "' data-dongID='" . $Val["fdDongid"] . "' data-chkInOutCode='" . $cmCode . "'>" . $Val["fdName"] . " <span class='interm-num'><span class='inTREM'>" . $inTERM . "</span>일</sapn></a></li>";
				$swiperHTML .="<div class='swiper-slide'></div>";
			}
			else{
				$menuHTML .="<li><a data-farmID='" . $Val["fdFarmid"] . "' data-dongID='" . $Val["fdDongid"] . "' data-chkInOutCode=''>" . $Val["fdName"] . " <span class='interm-num' style='background:gray'>출하</span></a></li>";
				$swiperHTML .="<div class='swiper-slide'></div>";
			}
		}
		//추가메뉴
		$menuHTML .="<li><a data-farmID='" . $Val["fdFarmid"] . "' data-dongID='None' data-chkInOutCode='search'>출하내역 <span class='interm-num'>검색</sapn></a></li>";
		$swiperHTML .="<div class='swiper-slide'></div>";
	}
	else{
		$menuHTML .="<li><a data-farmID='' data-dongID='' data-chkInOutCode=''>1동</a></li>
					 <li><a data-farmID='' data-dongID='' data-chkInOutCode=''>2동</a></li>
					 <li><a data-farmID='' data-dongID='' data-chkInOutCode=''>3동</a></li>";
		$swiperHTML ="<div class='swiper-slide'>slide1</div>
			 		  <div class='swiper-slide'>slide2</div>
					  <div class='swiper-slide'>slide3</div>";
	}
?>

<!DOCTYPE html>
<html lang="ko">
	<head>
		<meta charset="utf-8">
		<title>꼬꼬팜 :: KOKOFARM4</title>
		<meta name="description" content="">
		<meta name="author" content="">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
		
		<!-- #CSS Links -->
		<!-- Basic Styles -->
		<link rel="stylesheet" type="text/css" media="screen" href="../library/bootstrap/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" media="screen" href="../library/fonts/font-awesome.min.css">


		<!-- #FAVICONS -->
		<link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
		<link rel="icon" href="../images/icon.png" type="image/x-icon">


		<!-- smartadmin Styles : Caution! DO NOT change the order -->
		<link rel="stylesheet" type="text/css" media="screen" href="../library/smartadmin/smartadmin-production-plugins.min.css">
		<link rel="stylesheet" type="text/css" media="screen" href="../library/smartadmin/smartadmin-production.min.css">
		<link rel="stylesheet" type="text/css" media="screen" href="../library/smartadmin/smartadmin-skins.min.css">

		<!-- JQuery + Bootstrap -->
		<script src="../library/jquery/jquery.min.js"></script>					<!-- jQuery -->
		<script src="../library/jquery/jquery-ui-1.10.3.min.js"></script>			<!-- jQuery UI-->
		<script src="../library/bootstrap/bootstrap.min.js"></script>				<!-- BOOTSTRAP JS -->

		<!--Bootsteap Table-->
		<link rel="stylesheet" href="../library/bootstrap_table/bootstrap-table.css"/>
		<script src="../library/bootstrap_table/bootstrap-table.js"></script>

		<!--Bootstrap Datepicker-->
		<script src="../library/bootstrap_datepicker/bootstrap-datepicker.js" type="text/javascript"></script>
		<link rel="stylesheet" href="../library/bootstrap_datepicker/datepicker.css">

		<!--Bootstrap Clockpicker-->
		<script src="../library/bootstrap_clockpicker/src/clockpicker.js" type="text/javascript"></script>
		<link rel="stylesheet" href="../library/bootstrap_clockpicker/src/clockpicker.css">

		<!--amChart-->
		<script src="../library/amchart/amcharts.js" type="text/javascript"></script>
		<script src="../library/amchart/serial.js" type="text/javascript"></script>
		<script src="../library/amchart/lang/ko.js" type="text/javascript"></script>

		<!--swiper-->
		<script src="../library/swiper/swiper.min.js"></script>
		<link rel="stylesheet" href="../library/swiper/swiper.min.css"/>


		<!-- myDefined JS+CSS -->
		<script src="../library/my_define/my_define.js"></script>					<!-- my Defined JS-->
		<link rel="stylesheet" href="../library/my_define/my_define.css"/>		    <!-- my Defined CSS-->
	</head>
	<body>

		<header class="navbar-fixed-top">
			<div class="top-block">
				<img src="../images/logo2.png">
				<span class='label label-default' style='position:absolute;top:26px;left:160px'>ver 5.5</span>
				<p class="pull-right" style="padding-top:12px"><?=$farmNAME?></p>
			</div>
			<div class="top-menu">
				<div class="menu-block">
					<ul>
						<?=$menuHTML?>
					</ul>
				</div>
			</div>
		</header>

		<div class="swiper-container">
			<div class="swiper-wrapper">
				<?=$swiperHTML?>
			</div>
		</div>



		<!--입추형식 Modal--->
		<div class="modal fade" id="intypeModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog" style="width:90%;top:10%">
				<div class="modal-content">
					<form id="intypeFORM" onsubmit="return false;">
						<input type="hidden" name="chkInOutCode" value="">
						<input type="hidden" name="modal_origin" value="">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
							<h2 id="intypeModalTitle" class="modal-title" style="color:#A94442;font-weight:bold;">입추 설정 변경
							&nbsp;&nbsp;&nbsp;&nbsp;<label id="modal_dong_name" style="font-size:15px; color:black;">(대선팜1-01동)</label>
							</h2>
							
						</div>
						<div class="modal-body">
							<div style="padding:10px">

								<div class="col-xs-12 no-padding"><label style="color:#A94442; font-size:15px; font-weight:bold">※ 평균중량 최적화는 20일령 이후에 적용가능합니다.</label></div>
								<div class="col-xs-12 no-padding"><label style="color:#A94442; font-size:15px; font-weight:bold">※ 모든 변경사항은 관리자 승인후에 적용됩니다.</label></div>

								<div style="clear:both"></div>
								
								<div class="well">
									<div class="col-xs-12 no-padding">
										<div class="col-xs-12 no-padding" style=" text-align:center;"><label style="font-size:25px; font-weight:bold;">일령 변경</label></div>
										<div class="col-xs-12 no-padding" style=" text-align:right;"><label id="modal_in_time" style="font-size:13px; font-weight:bold; color:#A4A4A4">현재 입추시간 : (2021-03-02 00:00)</label></div>
									</div>
									
									<!--modal_alarm1-->
									<div class="col-xs-12 no-padding">
										<label id="modal_alarm1" style="font-size:14px; font-weight:bold; color:#A94442"></label>
									</div>

									<div class="col-xs-12 no-padding">
										<div class="col-xs-12 no-padding">
											<input class="form-control input-lg" type="text" id="in_datepicker" name="in_date" placeholder="입추일자">
										</div>
									</div>

									<!--modal_alarm2-->
									<div class="col-xs-12 no-padding">
										<label id="modal_alarm2" style="font-size:14px; font-weight:bold; color:#A94442"></label>
									</div>

									<div class="col-xs-12 no-padding">
										<div class="col-xs-12 no-padding">
											<input class="form-control input-lg" type="text" id="in_clockpicker" name="in_time" placeholder="입추시간" readonly>
										</div>
									</div>

									<div style="clear:both"></div>

								</div>

								<div class="well">
									<div class="col-xs-12 no-padding">
										<div class="col-xs-12 no-padding" style=" text-align:center;"><label style="font-size:25px; font-weight:bold">사육 변경</label></div>
									</div>
									<div class="col-xs-12 no-padding">
										<!--<div class="col-xs-3 no-padding">- 축종 </div>-->
										
										<div class="col-xs-12 no-padding">
											<div class="input-group" style="text-align:center; padding-bottom:15px">
												<label class="radio-inline">
													<input type="radio" class="radiobox style-0" name="changeIntype" value="육계"><span>&nbsp;육계</span>
												</label>&nbsp;&nbsp;
												<label class="radio-inline">
													<input type="radio" class="radiobox style-0" name="changeIntype" value="삼계"><span>&nbsp;삼계</span>
												</label>&nbsp;&nbsp;
												<label class="radio-inline">
													<input type="radio" class="radiobox style-0" name="changeIntype" value="토종닭"><span>&nbsp;토종닭</span>
												</label>
											</div><!--input-group-->
										</div>
									</div>
									<div class="col-xs-12 no-padding">
										<div class="col-xs-12 no-padding">
											<input class="form-control input-lg" type="text" name="changeInSU" placeholder="입추수" maxlength=6>
										</div>
									</div>

									<!--modal_alarm3-->
									<div class="col-xs-12 no-padding">
										<label id="modal_alarm3" style="font-size:14px; font-weight:bold; color:#A94442"></label>
									</div>

									<div style="clear:both"></div>

								</div>
								
								<div class="well">
									<div class="col-xs-12 no-padding">
										<div class="col-xs-12 no-padding" style="text-align:center;"><label style="font-size:25px; font-weight:bold">평균중량 최적화</label></div>
									</div>	

									<div class="col-xs-12 no-padding">
										<!--<div class="col-xs-3 no-padding">- 실측일자 </div>-->
										<div class="col-xs-12 no-padding" style="margin-top:15px">
											<input class="form-control input-lg" type="text" id="measure_datepicker" name="measure_date" placeholder="실측일자">
										</div>
									</div>

									<!--modal_alarm4-->
									<div class="col-xs-12 no-padding">
										<label id="modal_alarm4" style="font-size:14px; font-weight:bold; color:#A94442"></label>
									</div>

									<div class="col-xs-12 no-padding">
										<!--<div class="col-xs-3 no-padding">- 실측시간 </div>-->
										<div class="col-xs-12 no-padding">
											<input class="form-control input-lg" type="text" id="measure_clockpicker" name="measure_time" placeholder="실측시간" readonly>
										</div>
									</div>	

									<!--modal_alarm5-->
									<div class="col-xs-12 no-padding">
										<label id="modal_alarm5" style="font-size:14px; font-weight:bold; color:#A94442"></label>
									</div>

									<div class="col-xs-12 no-padding">
										<!--<div class="col-xs-3 no-padding">- 실측값 </div>-->
										<div class="col-xs-12 no-padding">
											<input class="form-control input-lg" type="text" id="measure_val" name="measure_val" placeholder="실측중량" maxlength=4>
										</div>
									</div>

									<!--modal_alarm6-->
									<div class="col-xs-12 no-padding">
										<label id="modal_alarm6" style="font-size:14px; font-weight:bold; color:#A94442"></label>
									</div>

									<div style="clear:both"></div>
								</div>

								<!--modal_alarm7-->
								<div class="col-xs-12 no-padding">
									<label id="modal_alarm7" style="font-size:14px; font-weight:bold; color:#A94442"></label>
								</div>
							
							</div>

							<div style="clear:both"></div>

						</div><!--modal-body-->

						<div class="modal-footer">
							<button type="submit" class="btn btn-danger">적용</button>
							<button type="button" class="btn btn-primary" data-dismiss="modal">닫기</button>
						</div><!--modal-footer-->

					</form>
				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div><!-- /.modal -->

		<!--Modal-->
		<div id="modalPopup" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="top:10%">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
						<h4 id="modalTitle" class="modal-title">Modal title</h4>
					</div>
					<div id="modalBody" class="modal-body">
						<p>One fine body…</p>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-primary" data-dismiss="modal">닫기</button>
					</div>
				</div><!--modal-content -->
			</div><!--modal-dialog -->
		</div><!--modal -->

		<!--Modal-->
		<div id="confirmModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="top:10%">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
						<h4 id="confirmModalTitle" class="modal-title" style="font-weight:bold;">Modal title</h4>
					</div>
					<div id="confirmModalBody" class="modal-body">
						<p>One fine body…</p>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-primary" data-dismiss="modal" id="confirm_ok">확인</button>
						<button type="button" class="btn btn-danger" data-dismiss="modal" id="confirm_cancle">취소</button>
					</div>
				</div><!--modal-content -->
			</div><!--modal-dialog -->
		</div><!--modal -->

	</body>
</html>

<script language="javascript">
	var farmID="";
	var dongID="";
	var	chkInOutCode="";

	var swiper = new Swiper('.swiper-container', {
		slidesPerView: 1,
		spaceBetween: 20,
		loop: false,
		/*autoHeight:true,*/
		init:false,
		initialSlide:0
	});

	$(document).ready(function(){
		swiper.init();

		$('#in_datepicker').datepicker({ 
				format: "yyyy-mm-dd",
				language: "kr",
				autoclose: true,
				disableTouchKeyboard: true
			}); //Date Picker 선언

		$('#measure_datepicker').datepicker({ 
				format: "yyyy-mm-dd",
				language: "kr",
				autoclose: true,
				disableTouchKeyboard: true
			
			}); //Date Picker 선언

		$('#in_clockpicker').clockpicker({		//clock picker
				placement: 'bottom',
				autoclose: true,
			    donetext: '입력완료',
				ignoreReadonly: true
			});

		$('#measure_clockpicker').clockpicker({		//clock picker
				placement: 'top',
				autoclose: true,
			    donetext: '입력완료',
				ignoreReadonly: true
			});
	});


	//swiper 최초시작 이벤트
	swiper.on('init', function() {	pageLoader();	});
	//swiper change 이벤트
	swiper.on('slideChange',function(){	pageLoader();	});


	//해당 페이지 호출
	function pageLoader(){
		var selectMenu=$(".menu-block > ul > li").eq(swiper.realIndex).find("a");	//선택한 메뉴
		selectMenu.trigger('click');

		var farmID=selectMenu.attr("data-farmID");			   //농장ID
		var dongID=selectMenu.attr("data-dongID");			   //동ID
		var chkInOutCode=selectMenu.attr("data-chkInOutCode"); //입추코드
		var addURL="?farmID=" + farmID + "&dongID=" + dongID + "&chkInOutCode=" + chkInOutCode;

		//입추인 경우
		if(farmID!=="" && dongID!=="" && chkInOutCode!==""){
			if(dongID==="None" && chkInOutCode==="search"){
				$(".swiper-slide [id]").prop('id','newId');//ID변경
				$(".swiper-slide").eq(swiper.realIndex).load("search.php" + addURL);	//출하내역 검색
			}
			else{
				$(".swiper-slide [id]").prop('id','newId');//ID변경
				$(".swiper-slide").eq(swiper.realIndex).load("chkin.php" + addURL);
			}
		}
		//출하인 경우
		if(farmID!=="" && dongID!=="" && chkInOutCode===""){
			$(".swiper-slide [id]").prop('id','newId');//ID변경
			$(".swiper-slide").eq(swiper.realIndex).load("chkout.php" + addURL);
		}
		//잘못된 ID/PW인 경우
		if(farmID==="" && dongID==="" && chkInOutCode===""){
			$(".swiper-slide").eq(swiper.realIndex).load("wrong.html");
		}

	}


	$(".menu-block ul li").click(function(){
		$(".menu-block ul li a").removeClass("on");
		$(this).find("a").addClass("on");
		//location.reload(); //화면새로고침
		if($(this).prev().offset()){
			$('.menu-block ul').animate({scrollLeft : ($('.menu-block ul').scrollLeft()+$(this).prev().offset().left)}, 400);
		}else{
			$('.menu-block ul').animate({scrollLeft : 0}, 400);
		}
		swiper.slideTo( $(this).index() );
	});



	//입추구분 변경
	function editIntype(chkInOutCode){
		if(chkInOutCode!=""){

			var dataArr={};
			dataArr['oper']="setModal";
			dataArr['chkInOutCode'] = chkInOutCode;

			$.ajax({url:'common_action.php',data:dataArr,cache:false,type:'post',dataType:'json',
				success: function(data) {
					//alert(JSON.stringify(data));

					// 기존
					$("#intypeFORM [name=changeIntype]").removeAttr("checked");
					$("#intypeFORM [name=changeIntype]:input[value=" + data.cmIntype + "]").prop("checked", true);
					$("#intypeFORM [name=chkInOutCode]").val(chkInOutCode);
					$("#intypeFORM [name=changeInSU]").val($("#summaryInsu").html());
					
					$in_date = data.cmIndate.substr(0,10);
					$in_time = data.cmIndate.substr(11,5);

					// 추가사항
					$("#modal_dong_name").html(data.fdName);
					$("#modal_in_time").html("현재 입추시간 : ("+ data.cmIndate.substr(0, 16) +")");
					$("#intypeFORM [name=in_date]").val($in_date);
					$("#intypeFORM [name=in_time]").val($in_time);

					// 변경사항 확인을 위한 변수
					$origin = data.cmIntype + "|" + data.cmIndate;
					$("#intypeFORM [name=modal_origin]").val($origin);

					$("#intypeModal").modal("show");
				}
			});
		}
	}

	//입추수량을 숫자만 입력
	$("#intypeFORM [name=changeInSU]").on("keyup", function() {
		$(this).val($(this).val().replace(/[^0-9]/g,""));
	});

	//실측값을 숫자만 입력
	$("#intypeFORM [name=measure_val]").on("keyup", function() {
		$(this).val($(this).val().replace(/[^0-9]/g,""));
	});

	// 일령변경, 축종변경, 최적화 요청
	$("#intypeFORM").submit(function() {

		var origin = $("#intypeFORM [name=modal_origin]").val().split("|");		// 0:cmIntype 1:cmIndate

		var tr_date = $("#intypeFORM [name=in_date]").val() + " " + $("#intypeFORM [name=in_time]").val();
		var tr_type = $("#intypeFORM [name=changeIntype]:checked").val();
		var tr_count = $("#intypeFORM [name=changeInSU]").val();
		var measure_date = $("#intypeFORM [name=measure_date]").val() + " " + $("#intypeFORM [name=measure_time]").val();
		var measure_val = $("#intypeFORM [name=measure_val]").val();

		//alert("origin : " + origin + "\ntr_date : " + tr_date + "\ntr_type : " + tr_type  + "\nmeasure_date : " + measure_date + "\nmeasure_val : " + measure_val);

		var notice = "";
		var days = $("#summaryInterm").html();

		var curr_day = get_now_date();

		// 축종 변경
		if(origin[0] != tr_type){
			notice += "- 축종을 <span style='font-weight:bold;'>\"" + origin[0] + "\"</span>에서 <span style='font-weight:bold;'>\"" + tr_type + "\"</span>으로 변경<br><br>";
		}

		// 입추수 변경
		var in_count = $("#summaryInsu").html();
		if(in_count != tr_count){
			notice += "- 입추수를 <span style='font-weight:bold;'>\"" + in_count + "\"</span>에서 <span style='font-weight:bold;'>\"" + tr_count + "\"</span>으로 변경<br><br>";
		}

		// 입추일자 오류처리
		if(origin[1].substr(0, 16) != tr_date){
			var date_diff = get_date_diff(tr_date, curr_day);
			
			if(date_diff >= 0){
				if(date_diff == 0){
					var time_diff = get_time_diff(tr_date + ":00", get_now_datetime());

					if(time_diff < 5){
						//Common_popupAlert("입추시간 입력 오류", "입력된 입추시간이 현재시간보다 큽니다. 확인 후 다시 입력해주세요");
						$("#modal_alarm1").html("! 입력된 입추시간이 현재시간보다 큽니다. 확인 후 다시 입력해주세요");
						$("#in_datepicker").focus();
						return;
					}
				}

				var origin_diff = get_date_diff(origin[1], curr_day) + 1;

				notice += "- 입추일자를 <span style='font-weight:bold;'>\"" + origin[1] + " ("+ origin_diff +"일령)\"</span>에서 <br>";
				notice += "<span style='font-weight:bold;'>\"" + tr_date + ":00 ("+ (date_diff + 1) +"일령)\"</span>으로 변경<br><br>";

			}
			else{
				//Common_popupAlert("입추일자 입력 오류", "입력된 입추시간이 현재시간보다 큽니다. 확인 후 다시 입력해주세요");
				$("#modal_alarm1").html("! 입력된 입추시간이 현재시간보다 큽니다.<br> 확인 후 다시 입력해주세요");
				$("#in_datepicker").focus();
				return;
			}
		}

		// 최적화 오류처리
		if(measure_date.length < 13 && measure_date.length > 2){	//아예 입력 안하거나 모두 입력해야 진행됨

			if(days < 20){
				//Common_popupAlert("일령 미달", "평균중량 최적화는 20일령 이후에 가능합니다");
				$("#modal_alarm4").html("! 평균중량 최적화는 20일령 이후에 가능합니다");
				return;
			}

			//Common_popupAlert("실측일자 입력 오류", "실측일자와 실측시간을 정확히 입력해주세요");
			$("#modal_alarm4").html("! 실측일자와 실측시간을 정확히 입력해주세요");
			$("#mesure_datepicker").focus();
			return;
		}

		if(measure_date.length > 13){	//실측일자 실측시간 모두 입력 시

			if(days < 20){
				//Common_popupAlert("일령 미달", "평균중량 최적화는 20일령 이후에 가능합니다");
				$("#modal_alarm4").html("! 평균중량 최적화는 20일령 이후에 가능합니다");
				return;
			}

			var date_diff = get_date_diff(measure_date, curr_day);

			//입력일 기준으로 3일 전까지의 실측값만 입력받음
			if(date_diff > 3){
				//Common_popupAlert("실측일자 입력 오류", "3일 이내에 실측한 값을 입력해주세요");
				$("#modal_alarm4").html("! 3일 이내에 실측한 값을 입력해주세요");
				return;
			}
			else if(date_diff = 0){
				var time_diff = get_time_diff(measure_date + ":00", get_now_datetime());
				
				// 30분 이내이면 오류 - 평균중량 재산출에 문제생김
				if(time_diff < 1800){
					//Common_popupAlert("실측시간 입력 오류", "실측시간은 현재시간보다 최소 30분 이전으로 입력해주세요");
					$("#modal_alarm5").html("! 실측시간은 현재시간보다 최소 30분 이전으로 입력해주세요");
					return;
				}
			}
			else if(date_diff < 0){
				//Common_popupAlert("실측일자 입력 오류", "입력된 실측시간이 현재시간보다 큽니다. 확인 후 다시 입력해주세요");
				$("#modal_alarm5").html("! 입력된 실측시간이 현재시간보다 큽니다. 확인 후 다시 입력해주세요");
				return;
			}

			
			if(measure_val.length == 0){	//실측값을 입력하지 않았으면
				//Common_popupAlert("실측값 입력 오류", "실측값을 정확히 입력해주세요");
				$("#modal_alarm6").html("! 실측값을 정확히 입력해주세요");
				$("#measure_val").focus();
				return;
			}
			else if(parseInt(measure_val) < 200 || parseInt(measure_val) > 2500){
				//Common_popupAlert("실측값 입력 오류", "실측값은 200 ~ 2500 사이의 값을 입력해주세요");
				$("#modal_alarm6").html("! 실측값은 200 ~ 2500 사이의 값을 입력해주세요");
				return;
			}

			notice += "- 평균중량 최적화를 <span style='font-weight:bold;'>\"" + measure_date + "\"</span>에 측정한 <span style='font-weight:bold;'>" + measure_val + "g</span>으로 진행<br><br>";

		}

		// 에러 확인 완료 후 적용될 값이 있으면 confirm창 출력
		if(notice.length < 1){
			//Common_popupAlert("입력 오류", "수정하여 적용할 값이 존재하지 않습니다");
			$("#modal_alarm7").html("! 수정하여 적용할 값이 존재하지 않습니다");
		}
		else{
			confirm_modal_popup("아래의 변경사항을 적용하시겠습니까?", notice, 
				function(confirm) {
					if(confirm){
						alert("적용");
					}
					else{
						alert("취소");
					}
				}
			);
		}



		// var dataArr={};
		// dataArr['oper']="request";
		// $.each($("#intypeFORM").serializeArray(),function(){ dataArr[this.name] = this.value; });
		// $.ajax({url:'common_action.php',data:dataArr,cache:false,type:'post',dataType:'json',
		// 	success: function(data) {
		// 		$("#intypeFORM").each(function() {	this.reset();  });
		// 		$("#summaryInType").html(data.summaryInType);
		// 		$("#intypeModal").modal("hide");

		// 		getData(farmID,dongID,chkInOutCode);  //자료 새로고침
		// 	}
		// });
	});

</script>


